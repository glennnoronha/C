#include <stdio.h>

int main() {
    unsigned int a = 5;      
    unsigned int b = 9;      
    unsigned int c = a & b;  
    unsigned int d = a | b;  
    printf("c: %u\n", c);
    return 0;
}
