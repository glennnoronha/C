int main() {
    int a = 10;
    int *ptr = &a;
    *ptr += 5;
    return 0;
}
