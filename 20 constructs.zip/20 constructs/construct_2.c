#include <stdio.h>

int main() {
    int a = 4, b = 6;
    int add = a + b;
    return 0;
}