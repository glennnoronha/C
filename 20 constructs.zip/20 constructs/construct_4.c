#include <stdio.h>

int main() {
    int a = 5;
    if (a == 5) {
        printf("a is 5\n");
    }   
    else{
        printf("a is not 5\n");
    }
    
    return 0;
}