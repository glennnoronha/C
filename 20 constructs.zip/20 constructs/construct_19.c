#include <stdio.h>

typedef int MyInt;

int main() {
    MyInt num = 13;
    printf("Value: %d\n", num);
    return 0;
}